import{l as t}from"./BP6NvnZ7.js";function i(r){return r instanceof t}export{i};
