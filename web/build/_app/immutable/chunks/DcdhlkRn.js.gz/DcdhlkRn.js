let e=0;const t=()=>`id-${e++}`;export{t as g};
