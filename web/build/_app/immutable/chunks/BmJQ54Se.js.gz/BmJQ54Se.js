import{i as o}from"./D0CSSuTl.js";const e=o({value:!1});export{e as i};
