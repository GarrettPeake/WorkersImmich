import{af as o,ag as a}from"./D0CSSuTl.js";function r(t=Symbol()){return{get:()=>a(t),set:e=>o(t,e)}}export{r as c};
