import{b as s}from"./gegweU97.js";function o(a,r){return s(a,r)}export{o as i};
