import{l as o,c as r}from"../chunks/gvLJu3l0.js";export{o as load_css,r as start};
